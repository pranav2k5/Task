import { Task } from '../lib/supabase';
import { Edit, Trash2, Clock, AlertCircle } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onStatusChange: (id: string, status: Task['status']) => void;
}

export function TaskCard({ task, onEdit, onDelete, onStatusChange }: TaskCardProps) {
  const statusColors = {
    pending: 'bg-orange-100 text-orange-800 border-orange-200',
    in_progress: 'bg-blue-100 text-blue-800 border-blue-200',
    completed: 'bg-green-100 text-green-800 border-green-200',
  };

  const priorityColors = {
    low: 'text-gray-600',
    medium: 'text-yellow-600',
    high: 'text-red-600',
  };

  const statusLabels = {
    pending: 'Pending',
    in_progress: 'In Progress',
    completed: 'Completed',
  };

  return (
    <div className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow border border-gray-200">
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-lg font-semibold text-gray-800 flex-1">{task.title}</h3>
          <div className="flex items-center space-x-2 ml-2">
            <button
              onClick={() => onEdit(task)}
              className="text-gray-400 hover:text-blue-600 transition-colors"
            >
              <Edit className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(task.id)}
              className="text-gray-400 hover:text-red-600 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {task.description && (
          <p className="text-gray-600 text-sm mb-4 line-clamp-3">{task.description}</p>
        )}

        <div className="flex items-center justify-between mb-4">
          <div className={`flex items-center space-x-1 ${priorityColors[task.priority]}`}>
            <AlertCircle className="w-4 h-4" />
            <span className="text-xs font-medium capitalize">{task.priority}</span>
          </div>
          <div className="flex items-center space-x-1 text-gray-400">
            <Clock className="w-4 h-4" />
            <span className="text-xs">{new Date(task.created_at).toLocaleDateString()}</span>
          </div>
        </div>

        <select
          value={task.status}
          onChange={(e) => onStatusChange(task.id, e.target.value as Task['status'])}
          className={`w-full px-3 py-2 rounded-lg border text-sm font-medium ${statusColors[task.status]}`}
        >
          <option value="pending">{statusLabels.pending}</option>
          <option value="in_progress">{statusLabels.in_progress}</option>
          <option value="completed">{statusLabels.completed}</option>
        </select>
      </div>
    </div>
  );
}
